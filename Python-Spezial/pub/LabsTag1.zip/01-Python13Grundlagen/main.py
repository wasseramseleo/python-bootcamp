transactions = [
    {"id": 101, "type": "deposit", "amount": 100.00, "currency": "EUR"},
    {"id": 102, "type": "withdrawal", "amount": 50.00, "currency": "EUR"},
    {"id": 103, "type": "deposit", "amount": 200.00, "currency": "USD"},
    {"id": 104, "type": "payment", "amount": 25.50, "currency": "EUR"},
    {"id": 105, "type": "withdrawal", "amount": 1000.00, "currency": "USD"},
]
